// server/src/utils/fetchEarnings.js
// 统一从 AlphaVantage + Finnhub 拉数据，并对齐/合并
// 说明：全部 CommonJS 写法，兼容你原项目（require/module.exports）

const fetch = require("node-fetch");


/** ====== 从全局 CONFIG 读取 ====== */
const AV_KEY = global.CONFIG?.ALPHA_VANTAGE_KEY;
const FINN_KEY = global.CONFIG?.FINNHUB_KEY;
const FMP_KEY = global.CONFIG?.FMP_KEY;
const EODHD_KEY = global.CONFIG?.EODHD_KEY;


/** ====== 小工具 ====== */
function safeNum(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}
function toISO(raw) {
  if (!raw) return null;
  // 支持 2025-06-30 / 2025/06/30 / 时间戳
  const d = new Date(
    typeof raw === "number" ? raw * 1000 : String(raw).replace(/\//g, "-")
  );
  return isNaN(d) ? null : d.toISOString().slice(0, 10);
}
function deriveSurprisePct(avPct, actual, estimate) {
  if (Number.isFinite(Number(avPct))) return +Number(avPct).toFixed(4);
  if (
    Number.isFinite(Number(actual)) &&
    Number.isFinite(Number(estimate)) &&
    Number(estimate) !== 0
  ) {
    return +(((Number(actual) - Number(estimate)) / Math.abs(Number(estimate))) * 100).toFixed(4);
  }
  return null;
}
function aiCode(s) {
  const v = Number(s);
  if (!Number.isFinite(v)) return "neutral";
  if (v >= 5) return "beat";
  if (v > 0) return "stable";
  if (v <= -5) return "miss";
  return "neutral";
}
async function safeJson(url, headers = {}) {
  try {
    const r = await fetch(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        Connection: "keep-alive",
        ...headers,
      },
      timeout: 15000,
    });
    if (!r.ok) {
      return { ok: false, status: r.status, data: null };
    }
    const data = await r.json();
    return { ok: true, status: r.status, data };
  } catch (e) {
    return { ok: false, status: null, data: null, error: e.message };
  }
}

/** ====== AlphaVantage: EPS 列表 ======
 * https://www.alphavantage.co/documentation/#earnings
 * 返回季度 EPS、estimate、surprisePercentage、fiscalDateEnding、reportedDate
 */
async function getAlphaEarnings(symbol) {
  if (!AV_KEY) return { ok: false, data: [] };

  const url = `https://www.alphavantage.co/query?function=EARNINGS&symbol=${symbol}&apikey=${AV_KEY}`;
  const { ok, data } = await safeJson(url);
  if (!ok || !data) return { ok: false, data: [] };

  // ✅ 新版接口字段兼容处理
  const list =
    data.quarterlyEarnings ||
    data.quarterlyReports ||
    data.quarterly_reports ||
    [];

  if (!Array.isArray(list) || !list.length) return { ok: false, data: [] };

  const rows = list.map((q) => ({
    fiscalDateEnding: toISO(q.fiscalDateEnding || q.fiscal_date_ending || null),
    reportedDate: q.reportedDate || q.reported_date || null,
    reportedEPS: safeNum(q.reportedEPS || q.reported_eps),
    estimatedEPS: safeNum(q.estimatedEPS || q.estimated_eps),
    surprise: deriveSurprisePct(
      q.surprisePercentage || q.surprise_percent,
      q.reportedEPS || q.reported_eps,
      q.estimatedEPS || q.estimated_eps
    ),
  }));

  return { ok: true, data: rows };
}



/** ====== Finnhub: 最近/下次财报日（calendar/earnings） ======
 * https://finnhub.io/docs/api/calendar-earnings
 * 该接口返回未来日历（以及窗口内历史），我们拿 symbol 的最近一条未来或最近一条记录
 */
async function getFinnhubUpcoming(symbol) {
  if (!FINN_KEY) return { ok: false, nextEarningsDate: null };
  // 给一个较宽窗口，拿最近一条（未来优先）
  const today = new Date();
  const start = new Date(today.getTime() - 3600 * 24 * 120 * 1000).toISOString().slice(0, 10);
  const end = new Date(today.getTime() + 3600 * 24 * 240 * 1000).toISOString().slice(0, 10);

  const url = `https://finnhub.io/api/v1/calendar/earnings?symbol=${symbol}&from=${start}&to=${end}&token=${FINN_KEY}`;
  const { ok, data } = await safeJson(url);
  if (!ok || !Array.isArray(data?.earningsCalendar)) {
    return { ok: false, nextEarningsDate: null };
  }
  const list = data.earningsCalendar
    .filter((x) => x?.symbol?.toUpperCase() === symbol)
  if (!list.length) return { ok: true, nextEarningsDate: null };

  // 优先选择 >= today 的最近一条；否则选最近历史一条
  const todayISO = toISO(today.toISOString().slice(0, 10));
  const future = list
    .filter((x) => toISO(x.date) >= todayISO)
    .sort((a, b) => (toISO(a.date) > toISO(b.date) ? 1 : -1));
  const past = list
    .filter((x) => toISO(x.date) < todayISO)
    .sort((a, b) => (toISO(a.date) > toISO(b.date) ? 1 : -1));

  const chosen = future[0] || past[past.length - 1] || null;
  return { ok: true, nextEarningsDate: chosen ? toISO(chosen.date) : null };
}

/** ====== Finnhub: EPS 历史（/stock/earnings） ======
 * https://finnhub.io/docs/api/company-earnings
 * 返回 period(YYYY-MM-DD)、actual、estimate、surprisePercent
 */
async function getFinnhubEpsHistory(symbol) {
  if (!FINN_KEY) return { ok: false, data: [] };
  const url = `https://finnhub.io/api/v1/stock/earnings?symbol=${symbol}&token=${FINN_KEY}`;
  const { ok, data } = await safeJson(url);
  if (!ok || !Array.isArray(data)) return { ok: false, data: [] };
  // 统一为 fiscalDateEnding = period
  const rows = data.map((r) => ({
    fiscalDateEnding: toISO(r?.period),
    reportedDate: toISO(r?.period),
    reportedEPS: safeNum(r?.actual),
    estimatedEPS: safeNum(r?.estimate),
    surprise: safeNum(r?.surprisePercent),
  }));
  return { ok: true, data: rows };
}

/** ====== Finnhub: 季度收入（/stock/financials?statement=ic&freq=quarterly） ======
 * https://finnhub.io/docs/api/financials
 * 返回 data: [{ period: '2025-06-30', revenue: 123, ...}, ...]
 */
async function getFinnhubRevenueQuarterly(symbol) {
  if (!FINN_KEY) return { ok: false, index: new Map() };
  const url = `https://finnhub.io/api/v1/stock/financials?symbol=${symbol}&statement=ic&freq=quarterly&token=${FINN_KEY}`;
  const { ok, data } = await safeJson(url);
  if (!ok || !Array.isArray(data?.data)) return { ok: false, index: new Map() };

  const idx = new Map();
  data.data.forEach((row) => {
    const k = toISO(row?.period);
    const rev = row?.revenue ?? row?.totalRevenue;
    if (k) idx.set(k, safeNum(rev));
  });
  return { ok: true, index: idx };
}

/** ====== 汇总：summary（最后一个季度） ======
 * 规则：
 * 1) 优先 AlphaVantage 的最新季度 EPS/Estimate/Surprise
 * 2) 收入来自 Finnhub quarterly financials 按 fiscalDateEnding 对齐
 * 3) 下次财报来自 Finnhub calendar
 */
async function assembleSummary(symbol) {
  // 1) Alpha EPS
  const av = await getAlphaEarnings(symbol);
  let last = av.ok && av.data.length ? av.data[0] : null;

  // 2) 如果 AV 不可用，用 Finnhub EPS 历史兜底
  if (!last) {
    const fhEps = await getFinnhubEpsHistory(symbol);
    if (fhEps.ok && fhEps.data.length) {
      // 取最新（period 越大越新）
      const sorted = fhEps.data
        .filter((r) => r.fiscalDateEnding)
        .sort((a, b) => (a.fiscalDateEnding > b.fiscalDateEnding ? -1 : 1));
      last = sorted[0] || null;
    }
  }

  if (!last) {
    const nextE = await getFinnhubUpcoming(symbol);
    return {
      ok: true,
      data: {
        symbol,
        lastReportDate: null,
        fiscalDateEnding: null,
        reportedEPS: null,
        estimatedEPS: null,
        surprise: null,
        reportedRevenue: null,
        estimatedRevenue: null,
        revenueSurprise: null,
        nextEarningsDate: nextE.ok ? nextE.nextEarningsDate : null,
        aiCode: "neutral"
      }
    };
  }
  

  // 3) 收入对齐
  const fhRev = await getFinnhubRevenueQuarterly(symbol);
  const rev = fhRev.ok ? fhRev.index.get(last.fiscalDateEnding) : null;

  // 4) 下次财报
  const nextE = await getFinnhubUpcoming(symbol);

  return {
    ok: true,
    data: {
      symbol,
      lastReportDate: last.reportedDate || null,
      fiscalDateEnding: last.fiscalDateEnding || null,
      reportedEPS: last.reportedEPS ?? null,
      estimatedEPS: last.estimatedEPS ?? null,
      surprise: last.surprise ?? null,
      reportedRevenue: rev ?? null,
      estimatedRevenue: null, // 多数源拿不到季度收入预期，留空
      revenueSurprise: null,  // 同上
      nextEarningsDate: nextE.ok ? nextE.nextEarningsDate : null,
      aiCode: aiCode(last.surprise),
    },
  };
}

/** ====== 历史：history（最近 N 季度） ======
 * 规则：
 * 1) 用 AlphaVantage 的季度 EPS 列表（最多 16）
 * 2) 用 Finnhub 的季度收入 index 对齐
 * 3) 如果 AV 没有，则用 Finnhub EPS 历史兜底
 */
async function assembleHistory(symbol, limit = 16) {
  let base = [];
  const av = await getAlphaEarnings(symbol);
  if (av.ok && av.data.length) {
    base = av.data;
  } else {
    const fhEps = await getFinnhubEpsHistory(symbol);
    if (fhEps.ok && fhEps.data.length) base = fhEps.data;
  }

  if (!base.length) {
    return { ok: true, data: [] };
  }

  // 对齐收入
  const fhRev = await getFinnhubRevenueQuarterly(symbol);
  const rows = base
    .filter((r) => r.fiscalDateEnding)
    .sort((a, b) => (a.fiscalDateEnding > b.fiscalDateEnding ? -1 : 1))
    .slice(0, limit)
    .map((row) => {
      const revenue = fhRev.ok ? fhRev.index.get(row.fiscalDateEnding) : null;
      const s = row.surprise;
      return {
        fiscalDateEnding: row.fiscalDateEnding,
        reportedDate: row.reportedDate || null,
        reportedEPS: row.reportedEPS ?? null,
        estimatedEPS: row.estimatedEPS ?? null,
        surprise: Number.isFinite(Number(s)) ? +Number(s).toFixed(4) : null,
        revenue: revenue ?? null, // USD
        aiCode: aiCode(s),
      };
    });

  return { ok: true, data: rows };
}

module.exports = {
  assembleSummary,
  assembleHistory,
};
