// server/src/routes/earningsCalendar.js
const express = require("express");
const fetch = require("node-fetch");
const router = express.Router();

// Financial Modeling Prep 官方API（建议替换为自己的apikey）
const API_KEY = process.env.FMP_API_KEY || "demo"; // ⚠️ demo仅作测试，建议换成自己的key

// 缓存机制（减少API调用频率）
const cache = new Map();
const CACHE_TTL = 1000 * 60 * 30; // 缓存30分钟

// ============================
// 获取最近或即将公布的财报日历
// ============================
router.get("/", async (req, res) => {
  try {
    const now = Date.now();
    const cached = cache.get("earningsCalendar");
    if (cached && now - cached.time < CACHE_TTL) {
      return res.json({ ok: true, data: cached.data, cached: true });
    }

    // 请求最新财报数据（limit=50 表示最多取50家公司）
    const resp = await fetch(
      `https://financialmodelingprep.com/api/v3/earning_calendar?limit=50&apikey=${API_KEY}`
    );

    const data = await resp.json();

    // 数据检查
    if (!Array.isArray(data) || data.length === 0) {
      return res.json({ ok: false, message: "No calendar data found" });
    }

    // 结构化结果
    const formatted = data.map((item) => ({
      symbol: item.symbol,
      reportDate: item.date || "未知",
      eps: item.eps,
      epsEstimated: item.epsEstimated,
      time: item.time || "N/A",
      revenue: item.revenue ? `$${(item.revenue / 1e9).toFixed(2)}B` : "—",
      fiscalQuarter: item.fiscalDateEnding || "—",
    }));

    // 写入缓存
    cache.set("earningsCalendar", { time: now, data: formatted });

    res.json({ ok: true, data: formatted });
  } catch (err) {
    console.error("earningsCalendar error:", err);
    res.status(500).json({ ok: false, error: err.message });
  }
});

module.exports = router;
