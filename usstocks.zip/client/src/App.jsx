// client/src/App.jsx
import React, { useEffect, useState } from "react";
import Layout from "./components/Layout";
import Watchlist from "./components/Watchlist";
import EarningsCalendar from "./components/EarningsCalendar";
import EarningsChart from "./components/EarningsChart";

export default function App() {
  const [view, setView] = useState("watchlist");

  // 记住语言：默认中文；切换后写入 localStorage
  const [lang, setLang] = useState(localStorage.getItem("lang") || "zh");
  useEffect(() => { localStorage.setItem("lang", lang); }, [lang]);

  const t = (en, zh) => (lang === "zh" ? zh : en);

  return (
    <Layout lang={lang} setLang={setLang} view={view} setView={setView} t={t}>
      {view === "watchlist" && <Watchlist lang={lang} t={t} />}
      {view === "calendar" && <EarningsCalendar lang={lang} t={t} />}
      {view === "charts" && <EarningsChart lang={lang} t={t} />}
      {view !== "watchlist" && view !== "calendar" && view !== "charts" && (
        <div className="sa-card p-6 text-gray-700">
          {t("Coming soon…", "即将推出…")}
        </div>
      )}
    </Layout>
  );
}
