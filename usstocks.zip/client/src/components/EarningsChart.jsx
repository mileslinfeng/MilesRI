import React, { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend, ResponsiveContainer } from "recharts";

export default function EarningsChart() {
  const [symbol, setSymbol] = useState("AAPL");
  const [data, setData] = useState([]);

  useEffect(() => {
    async function loadChart() {
      const res = await fetch(`http://localhost:5050/api/earningsHistory/${symbol}`);
      const json = await res.json();
      setData(json.data || []);
    }
    loadChart();
  }, [symbol]);

  return (
    <div className="max-w-5xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">📊 EPS & 收入历史趋势</h2>
      <div className="flex gap-2 mb-6">
        <input
          type="text"
          value={symbol}
          onChange={(e) => setSymbol(e.target.value.toUpperCase())}
          className="border px-3 py-2 rounded-lg"
          placeholder="输入股票代码，如 AAPL"
        />
      </div>

      {data.length === 0 ? (
        <p className="text-gray-500">暂无历史数据</p>
      ) : (
        <ResponsiveContainer width="100%" height={400}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="fiscalDateEnding" />
            <YAxis yAxisId="left" />
            <YAxis yAxisId="right" orientation="right" />
            <Tooltip />
            <Legend />
            <Line yAxisId="left" type="monotone" dataKey="reportedEPS" stroke="#2563eb" name="EPS" />
            <Line yAxisId="right" type="monotone" dataKey="totalRevenue" stroke="#16a34a" name="收入" />
          </LineChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
