import React, { useEffect, useState } from "react";

export default function EarningsCalendar() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchCalendar() {
      setLoading(true);
      try {
        const res = await fetch("http://localhost:5050/api/earningsCalendar");
        const json = await res.json();
        setData(json.data || []);
      } catch {
        setData([]);
      }
      setLoading(false);
    }
    fetchCalendar();
  }, []);

  return (
    <div className="max-w-6xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">📅 财报预告日历</h2>
      {loading ? (
        <p className="text-gray-500">加载中...</p>
      ) : data.length === 0 ? (
        <p className="text-gray-500">暂无财报预告数据。</p>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {data.map((item) => (
            <div key={item.symbol} className="p-4 bg-white border rounded-lg shadow-sm hover:shadow-md transition">
              <h3 className="font-bold text-lg mb-1">{item.symbol}</h3>
              <p className="text-sm text-gray-700">
                公布日期：<b>{item.reportDate}</b>
              </p>
              <p className="text-sm">时间：{item.reportTime}</p>
              <p className="text-sm">EPS预期：{item.epsEstimate || "—"}</p>
              <p className="text-sm text-gray-500 mt-1">
                来源：{item.source || "预估数据"}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
