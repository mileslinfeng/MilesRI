import React from "react";

export default function Header({ lang, setLang }) {
  return (
    <header className="sa-header flex items-center justify-between">
      {/* 左侧标题区：删除了搜索框 */}
      <h1 className="text-lg font-bold text-gray-900">Earnings Pro</h1>

      {/* 右侧语言切换按钮 */}
      <button
        className="lang-switch"
        onClick={() => setLang(lang === "zh" ? "en" : "zh")}
      >
        {lang === "zh" ? "EN" : "中文"}
      </button>
    </header>
  );
}
