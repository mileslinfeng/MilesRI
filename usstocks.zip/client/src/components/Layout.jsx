//D:\usstocks\client\src\components\Layout.jsx
import React from "react";
import Header from "./Header";
import Sidebar from "./Sidebar";

export default function Layout({ lang, setLang, view, setView, t, children }) {
  return (
    <div className="sa-layout">
      <Header lang={lang} setLang={setLang} />
      <div className="sa-body">
        <Sidebar view={view} setView={setView} t={t} />
        <main className="sa-main">
          <div className="max-w-7xl mx-auto p-5">{children}</div>
        </main>
      </div>
    </div>

  );
}

